"""
this is just a simple port scanner to check for the available ports on the
hope this shit works like the way i intend to make it work across all the systems

all I need is the ip and then i will scan for the famous ports
to see if they are running on a particular system
"""

from parse.parse import parse

"""
this is going to use optParse on the argument vector from the cli.
simple right huh?
"""
import optparse
__all__ = ["parse"]


def parse(usage=None, *args):
    parser = optparse.OptionParser(usage)
    arguments = [x for x in args]
    i = 0

    while i < len(arguments) + 1:
        try:
            parser.add_option(arguments[i], dest=arguments[i+1], type="string")
        except IndexError:
            pass
        i += 2

    (options, arg) = parser.parse_args()

    return options


if __name__ == '__main__':
    parsed = parse("Usage %prog", "-f", "filename", "-a", "read")
    print(parsed.filename)
    print(type("")(2))

